from django.apps import AppConfig


class ProfileMakerConfig(AppConfig):
    name = 'profile_maker'
