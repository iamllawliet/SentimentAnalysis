

# Create your models here.
from django.db import models


class User_Profile(models.Model):
    Firstname = models.CharField(max_length=200)
    Surname = models.CharField(max_length=200)
    Email = models.EmailField(default=None)
    Document = models.FileField()

    def __str__(self):
        return self.fname
