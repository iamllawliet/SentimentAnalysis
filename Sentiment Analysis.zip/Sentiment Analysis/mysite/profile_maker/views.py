from django.shortcuts import render
from .forms import Profile_Form
from .models import User_Profile
from .sentiment import Sentiment

IMAGE_FILE_TYPES = ['txt']


def create_profile(request):
    form = Profile_Form()
    if request.method == 'POST':
        form = Profile_Form(request.POST, request.FILES)
        if form.is_valid():
            user_pr = form.save(commit=False)
            user_pr.doc = request.FILES['Document']
            file_type = str((user_pr.doc).name).split('.')[-1]
            file_type = file_type.lower()
            if file_type not in IMAGE_FILE_TYPES:
                return render(request, 'profile_maker/error.html')
            user_pr.save()
            Sentiment.blob(
                './media/sa.txt')
            return render(request, 'profile_maker/details.html', {'user_pr': user_pr})
    context = {"form": form, }
    return render(request, 'profile_maker/create.html', context)
